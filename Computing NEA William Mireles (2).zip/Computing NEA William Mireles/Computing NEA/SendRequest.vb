﻿Public Class SendRequest
    Private Sub BtnMenu_Click(sender As Object, e As EventArgs) Handles BtnMenu.Click
        ' Hides current form
        Me.Hide()
        ' Redirects them to customermenu
        CustomerMenu.Show()
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles BtnClear.Click
        ' Clears all fields
        txtMsg.Clear()
        RequestType.Text = ""
    End Sub

    Private Sub BtnSend_Click(sender As Object, e As EventArgs) Handles BtnSend.Click
        ' Defines new connection
        Dim conn As New System.Data.OleDb.OleDbConnection()
        ' Defines location of the database
        conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\\Ccw03usr02\2018$\WM180573\MongooseGames.accdb"
        ' Opens connection to the database
        conn.Open()
        ' SQL (Structured Query Lanugage) statement which inserts what the staff member input into the database in the corresponding table
        Dim sql As String = "INSERT INTO CustRequests(CustUser,RequestType,Message) VALUES ('" & CustomerLogin.txtUsername.Text & "', '" & RequestType.Text & "', '" & txtMsg.Text & "')"
        ' Allows the sql command to be executed against the database
        Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)
        ' Customer is notififed of their success of their required task.
        MessageBox.Show("Request sent", "Sending of request successful")
        'Open Database Connection again
        sqlCom.Connection = conn

        ' Carry out the sql statement
        Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()

        ' Close the connection to the database
        conn.Close()
        ' Clears all fields
        txtMsg.Clear()
        RequestType.Text = ""
    End Sub
End Class