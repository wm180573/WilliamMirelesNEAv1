﻿Public Class CustomerMenu
    Private Sub BtnLogout_Click(sender As Object, e As EventArgs) Handles BtnLogout.Click
        ' Hides current form
        Me.Hide()
        ' Redirects to first menu screen
        Form1.Show()
    End Sub

    Private Sub BtnSendRequest_Click(sender As Object, e As EventArgs) Handles BtnSendRequest.Click
        Me.Hide()
        SendRequest.Show()
    End Sub

    Private Sub BtnViewRequests_Click(sender As Object, e As EventArgs) Handles BtnViewRequests.Click
        Me.Hide()
        ViewRequestReplies.Show()
    End Sub
End Class