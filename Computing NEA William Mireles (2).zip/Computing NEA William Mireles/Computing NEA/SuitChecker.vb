﻿Public Class SuitChecker
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim conn As New System.Data.OleDb.OleDbConnection()
        conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\\Ccw03usr02\2018$\WM180573\MongooseGames.accdb"

        'Dim sql As String = "SELECT COUNT(*) AS total FROM Games WHERE GameName = CS:GO;"
        Dim sql As String = "SELECT COUNT(*) FROM Games WHERE (GameName) = ('" & TextBox1.Text & "')"

        Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)

        'Open Database Connection
        sqlCom.Connection = conn
        conn.Open()

        Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()

    End Sub
End Class